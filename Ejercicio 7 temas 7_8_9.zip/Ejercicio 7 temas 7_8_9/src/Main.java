import java.lang.ArithmeticException;

public class Main {
    public static void main(String[] args) {
        try {
            DividePorCero();
        } catch (ArithmeticException e) {
            System.out.println("Esto no puede hacerse");
        }
        System.out.println("Demo de código");
    }

    public static void DividePorCero() throws
            ArithmeticException {
        int a = 5;
        int b = 0;
        if (b == 0) {
            throw new ArithmeticException();
        }
        int c = a / b;
    }
}