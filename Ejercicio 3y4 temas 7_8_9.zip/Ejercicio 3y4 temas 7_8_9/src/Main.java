import java.util.Vector;

public class Main {
    public static void main(String[] args) {
        // Crea un vector, despues añade 5 elementos(elems)
        Vector<Integer> miVector = new Vector<Integer>();
        miVector.add(1);
        miVector.add(2);
        miVector.add(3);
        miVector.add(4);
        miVector.add(5);

        // Elimina el segundo y el tercer elem, y muestra el resultado final
        miVector.remove(1);
        miVector.remove(1);
        for(int i = 0; i < miVector.size(); i++) {
            System.out.println(miVector.get(i));
        }
    }
    /*
        El problema de utilizar un Vector con la capacidad por defecto si quisieramos añadir 1000 elems,
        es que, cada vez que se llena el Vector, se debe crear un nuevo Vector con una capacidad mayor
        y copiar todos los elems del Vector original al nuevo Vector.
        Esto puede ser costoso en términos de tiempo de ejecución y uso de memoria.
    */
}
