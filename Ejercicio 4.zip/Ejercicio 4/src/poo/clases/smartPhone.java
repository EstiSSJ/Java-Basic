package poo.clases;

public class smartPhone extends smartDevice {
    String marca;
    String modelo;
    int cantProces;
    double screen;
    String cam;
    String cache;
    String RAM;
    String systOP;

    public smartPhone() {
    }

    public smartPhone(String marca, String modelo, int cantProces, double screen, String cam, String cache, String RAM, String systOP) {
        this.marca = marca;
        this.modelo = modelo;
        this.cantProces = cantProces;
        this.screen = screen;
        this.cam = cam;
        this.cache = cache;
        this.RAM = RAM;
        this.systOP = systOP;
    }
}

