package poo.clases;

public class smartWatch extends smartDevice{
    String marca;
    String modelo;
    boolean tactilScreen;
    double screen;
    String cache;
    String RAM;
    String systOP;

    public smartWatch() {
    }

    public smartWatch(String marca, String modelo, boolean tactilScreen, double screen, String cache, String RAM, String systOP) {
        this.marca = marca;
        this.modelo = modelo;
        this.tactilScreen = tactilScreen;
        this.screen = screen;
        this.cache = cache;
        this.RAM = RAM;
        this.systOP = systOP;
    }
}

