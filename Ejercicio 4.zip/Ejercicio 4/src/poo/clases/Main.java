package poo.clases;

import poo.clases.smartDevice;
import poo.clases.smartPhone;
import poo.clases.smartWatch;

public class Main {
    public static void main(String[] args) {
        smartPhone SamsungA51 = new smartPhone("Samsung", "A51", 8, 6.5, "48 Mpx", "128 GB", "4 GB", "Android 10");
        System.out.println("Mi celular es un: ");
        System.out.println(SamsungA51.marca + " " + SamsungA51.modelo + ",");
        System.out.println("El procesador tiene " + SamsungA51.cantProces + " nucleos");
        System.out.println("El tamaño de la pantalla es de " + SamsungA51.screen + " pulgadas");
        System.out.println("La resolución de la camara frontal es de " + SamsungA51.cam);
        System.out.println("Una memoria interna de " + SamsungA51.cache);
        System.out.println("Una RAM de " + SamsungA51.RAM);
        System.out.println("Y el sistema operativo es " + SamsungA51.systOP);

        System.out.println();

        smartWatch XiaomiKW66 = new smartWatch("Xiaomi", "KW66", true, 1.28, "128 MB", "160 kB", "Android 4.4, iOS 7.0");
        System.out.println("Mi reloj SmartWatch es un: ");
        System.out.println(XiaomiKW66.marca + " " + XiaomiKW66.modelo + ",");
        System.out.println("El tamaño de la pantalla es de " + XiaomiKW66.screen + " pulgadas");
        System.out.println("Una memoria interna de " + XiaomiKW66.cache);
        System.out.println("Una RAM de " + XiaomiKW66.RAM);
        System.out.println("Los sistemas operativos compatibles del SmartWatch son: " + XiaomiKW66.systOP);
        System.out.println("¿Tiene pantalla táctil? " + XiaomiKW66.tactilScreen);
    }
}
