package poo.clases;

public class smartDevice {
    String marca;
    String modelo;
    String peso;
    double cam;
    String screen;
    int cache;
    int RAM;
    String procesador;
    String systOP;

    public smartDevice() {
    }

    public smartDevice(String marca, String modelo, String peso, double cam, String screen, int cache, int RAM, String procesador, String systOP) {
        this.marca = marca;
        this.modelo = modelo;
        this.peso = peso;
        this.cam = cam;
        this.screen = screen;
        this.cache = cache;
        this.RAM = RAM;
        this.procesador = procesador;
        this.systOP = systOP;
    }
}


