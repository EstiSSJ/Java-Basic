import java.io.InputStream;
import java.io.PrintStream;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        numberGuessingGame game = new numberGuessingGame();
        game.run(System.in, System.out);
    }
}
class numberGuessingGame {
    public void run(InputStream input, PrintStream output) {
        // Crea un generador de números aleatorios
        Random random = new Random();

        // Genera el número secreto
        int secretNumber = random.nextInt(100) + 1;

        // Crea el HashMap que almacena las pistas
        HashMap<Integer, String> clues = new HashMap<>();

        // Crea el ArrayList que almacena los números adivinados
        ArrayList<Integer> guesses = new ArrayList<>();

        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(input);

        while (true) {
            output.print("Adivina el número (1-100): ");
            // Se lee el número adivinado por el usuario
            int guess;
            try {
                 guess = scanner.nextInt();
            } catch (InputMismatchException e) {
                // Si el usuario no introduce un número entero, se muestra un mensaje de error
                // y se vuelve a pedir que ponga un num Int
                output.println("Por favor, introduce un número entero.");
                break;
            }

            // Se añade el número adivinado al ArrayList
            guesses.add(guess);

            if (guess == secretNumber) {
                // Si el usuario ha acertado, se muestra un mensaje de felicitación
                // y termina el juego
                output.println("¡Felicidades, has acertado crack!");
                break;
            } else if (guess < secretNumber) {
                // Si el número adivinado es menor que el número secreto,
                // se añade una pista al HashMap y se vuelve a pedirle que adivine
                clues.put(guess, "mayor");
                output.println("El número es mayor.");
            } else {
                // Lo mismo que lo anterior pero al reves
                clues.put(guess, "menor");
                output.println("El número es menor.");
            }
        }
    }
}