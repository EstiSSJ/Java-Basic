public class arrBidimensional {
    // Atributo que almacena el array bidimensional de enteros
    private int[][] arrayBi;

    public arrBidimensional(int[][] array) {
        this.arrayBi = array;
    }

    // Método que recorre el array bidimensional y muestra la posición y el valor de cada elemento
    public void mostrarElementos() {
        for (int i = 0; i < arrayBi.length; i++) {
            for (int j = 0; j < arrayBi[i].length; j++) {
                System.out.println("Posición [" + i + "][" + j + "]: " + arrayBi[i][j]);
            }
        }
    }
}
