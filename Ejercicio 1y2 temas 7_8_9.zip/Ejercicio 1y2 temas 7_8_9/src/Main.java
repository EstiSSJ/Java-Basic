public class Main {
    public static void main(String[] args) {
        // Crear el array de Strings
        String[] array = {"valor 1", "valor 2", "valor 3", "valor 4"};

        // Crear el objeto de la clase arrUnidimensional
        arrUnidimensional obj = new arrUnidimensional(array);

        // Mostrar los valores del array
        obj.mostrarValores();

        System.out.println();

        // Crear el array bidimensional de enteros
        int[][] arrayBi = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        // Crear el objeto de la clase arrBidimensional
        arrBidimensional object = new arrBidimensional(arrayBi);

        // Mostrar los elementos del array
        object.mostrarElementos();
        }
    }