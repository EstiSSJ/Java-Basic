public class arrUnidimensional {

    // Atributo que almacena el array de Strings
    private String[] array;

    public arrUnidimensional(String[] array) {
        this.array = array;
    }

    // Método que recorre el array y muestra sus valores
    public void mostrarValores() {
        for (String valor : array) {
            System.out.println(valor);
        }
    }
}
