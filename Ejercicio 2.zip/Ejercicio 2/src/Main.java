public class Main {
    public static void main(String[] args) {
        System.out.println(getPricePlusIVA(150));
        System.out.println(getPricePlusIVA(110));
    }
    static double IVA = 0.18;
    static double getPricePlusIVA(int precio) {
        return precio * (1 + IVA);
    }
}