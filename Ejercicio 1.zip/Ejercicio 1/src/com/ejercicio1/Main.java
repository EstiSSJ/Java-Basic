package com.ejercicio1;

public class Main {
    public static void main(String[] args) {
        System.out.println("boolean: representa un valor lógico verdadero o falso.\n" +
                "\n" +
                "byte: representa un número entero de 8 bits sin signo.\n" +
                "\n" +
                "short: representa un número entero de 16 bits sin signo.\n" +
                "\n" +
                "int: representa un número entero de 32 bits sin signo.\n" +
                "\n" +
                "long: representa un número entero de 64 bits sin signo.\n" +
                "\n" +
                "float: representa un número de punto flotante de 32 bits.\n" +
                "\n" +
                "double: representa un número de punto flotante de 64 bits.\n" +
                "\n" +
                "char: representa un carácter Unicode de 16 bits.\n" +
                "\n" +
                "String: representa una cadena de caracteres. Aunque String no es un tipo de dato primitivo, es muy comúnmente usado en Java y se comporta de manera similar a los tipos de datos primitivos.");

    }
}
