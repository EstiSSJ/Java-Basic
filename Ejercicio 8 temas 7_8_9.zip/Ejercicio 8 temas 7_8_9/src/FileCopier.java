import java.io.*;

public class FileCopier {
    public static void copyFile(String fileIn, String fileOut) throws IOException {
        // Abre el InputStream desde el fichero fileIn
        InputStream in = new FileInputStream(fileIn);
        // Abre el PrintStream hacia el fichero fileOut
        PrintStream out = new PrintStream(new FileOutputStream(fileOut));

        // Bucle para leer el fichero de entrada carácter a carácter
        int c;
        while ((c = in.read()) != -1) {
            // Escribe cada carácter en el fichero de salida
            out.write(c);
        }

        // Cierra el InputStream y el PrintStream
        in.close();
        out.close();
    }
}

