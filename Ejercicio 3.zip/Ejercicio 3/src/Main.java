public class Main {
    public static void main(String[] args) {

        String[] nombres = {"Pepe ", "Juan ", "Malini ", "Kazchiv"};
        String plus = "";

        for (String nombre : nombres) {
            plus = plus + nombre;
        }
        System.out.println(plus);
    }
}