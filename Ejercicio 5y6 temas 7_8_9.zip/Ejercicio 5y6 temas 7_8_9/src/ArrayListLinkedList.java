import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListLinkedList {
    // Método para crear y copiar un ArrayList en una LinkedList
    public static void crearYCopiar() {
        // Crea un ArrayList de tipo String con 4 elementos
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Elemento 1");
        arrayList.add("Elemento 2");
        arrayList.add("Elemento 3");
        arrayList.add("Elemento 4");

        // Copia el ArrayList en una LinkedList
        LinkedList<String> linkedList = new LinkedList<>(arrayList);

        // Recorrer y mostrar los elementos del ArrayList
        System.out.println("ArrayList:");
        for (String elem : arrayList) {
            System.out.println(elem);
        }

        // Recorre y muestra los elementos de la LinkedList
        System.out.println("LinkedList:");
        for (String elem : linkedList) {
            System.out.println(elem);
        }
    }
}

