import java.util.ArrayList;

public class ArrayListInt {
    // Método para crear un ArrayList de enteros y eliminar los números pares
    public static void crearYEliminarPares() {
        // Crea un ArrayList de tipo int y rellena con elementos del 1..10
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            arrayList.add(i);
        }

        // Recorre el ArrayList y elimina los números pares
        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i) % 2 == 0) {
                arrayList.remove(i);
                i--;
            }
        }

        // Recorre y muestra el ArrayList final
        System.out.println("ArrayList final:");
        for (int elemento : arrayList) {
            System.out.println(elemento);
        }
    }
}
