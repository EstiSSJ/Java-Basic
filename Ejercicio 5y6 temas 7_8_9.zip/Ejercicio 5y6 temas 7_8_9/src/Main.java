public class Main {
    public static void main(String[] args) {
            ArrayListLinkedList.crearYCopiar();

            System.out.println();

            ArrayListInt.crearYEliminarPares();
    }
}