 public interface CocheCRUD {
        void save();
        void findAll();
        void delete();
    }

